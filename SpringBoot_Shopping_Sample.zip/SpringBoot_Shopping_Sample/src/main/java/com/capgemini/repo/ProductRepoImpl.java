package com.capgemini.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.bean.Product;
@Repository
public class ProductRepoImpl implements ProductRepo {

	@PersistenceContext
	private EntityManager entitymanager;
	@Override
	@Transactional
	public Product updateProduct(Product updatedProduct) {
		
		
		Product product;
		product = entitymanager.find(Product.class, updatedProduct.getId());
		if(product==null) {
			return null;
		}
		product.setName(updatedProduct.getName());
		product.setModel(updatedProduct.getModel());
		product.setPrice(updatedProduct.getPrice());
		
		
	    		
		return product;
	}
	

	@Override
	@Transactional
	public boolean save(Product product) {
			Product p = findById(product.getId());
			if(p == null)
			{
				entitymanager.persist(product);
				return true;
			}
			else 
			{ 
				return false;
			}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cg.repo.WalletRepo#search(java.lang.String)
	 */
	@Override
	public Product findById(String id) {
		
	
		
		Product product = entitymanager.find(Product.class,id);
		
		if(product != null) {
			return product;
		}
		return null;
	}

	
	@Override
	@Transactional
	public boolean deleteById(String id) {
		try {
			
			Product p = findById(id);
			
			if(p != null) {
				entitymanager.remove(p);
				return true;
			}
			else { 
				return false;
			}
		}
		catch (Exception e) {
			
			System.out.println("Exception in Deleting Product");
		}
		return false;
	}
	@Override
	@Transactional
	public List<Product> viewproducts() {
		
		List<Product> list=new ArrayList<>();
		
		Query query=entitymanager.createQuery("select p from Product p");
		
		list= query.getResultList();
		
		return list;
	}	
	public static boolean closeConnection() {
		
		return false;
	}
		
	}
	

