package com.capgemini.repo;

import java.util.List;

import com.capgemini.bean.Product;

public interface ProductRepo {
	public Product updateProduct(Product updatedProduct);
	public boolean save(Product product);
	public Product findById(String id);
	public boolean deleteById(String id);
	public List<Product> viewproducts();
	
}
