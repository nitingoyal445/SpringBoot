package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.Product;
import com.capgemini.exception.IdAlreadyExistException;
import com.capgemini.exception.IdNotFoundException;
import com.capgemini.repo.ProductRepoImpl;
@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductRepoImpl productRepoImpl;
	@Override
	public Product getSpecificProduct(String id) {
		// TODO Auto-generated method stub

		
		if(productRepoImpl.findById(id)==null)
			throw new IdNotFoundException("Id not found");
		return (productRepoImpl.findById(id));
		
	}
	@Override
	public boolean addProduct(Product product) {
		if(productRepoImpl.save(product))
		return true;
		else {
			throw new IdAlreadyExistException("Id Already Exist");
		}
		
	}
	@Override
	public boolean deleteProduct(String id) {
		if(productRepoImpl.deleteById(id))
			return true;
		else {
			throw new IdNotFoundException("Id not Found");
		}
		
	}
	@Override
	public Product updateProduct(Product product) {
		if(productRepoImpl.updateProduct(product)!=null)
			return productRepoImpl.updateProduct(product);
		else {
			throw new IdNotFoundException("Id not found");
		}
		
	}
	@Override
	public List<Product> viewProducts() {
		return productRepoImpl.viewproducts();
	}
	@Override
	public boolean closeConnection() {
		ProductRepoImpl.closeConnection();
		return true;
	}

}
