package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.Product;

public interface ProductService {
	public Product getSpecificProduct(String id);
	public boolean deleteProduct(String id);
	public boolean addProduct(Product product);
	public Product updateProduct(Product product);
	public List<Product> viewProducts();
	public boolean closeConnection();
}
