package com.capgemini.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bean.Product;

import com.capgemini.service.ProductServiceImpl;

@RestController
public class ProductController {
	@Autowired
	ProductServiceImpl productServiceImpl;
	
	@RequestMapping("/product/{id}")
	public Product getSpecificEmployee(@PathVariable String id) {
		return productServiceImpl.getSpecificProduct(id);
		
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/addProduct")
	public boolean addProduct(@Valid @RequestBody Product product) {
		
			return (productServiceImpl.addProduct(product));		
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/updateProduct")
	public Product updateProduct(@RequestBody Product product) {
		return productServiceImpl.updateProduct(product);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/deleteProduct/{id}")
	public boolean deleteProduct(@PathVariable String id) {
		return productServiceImpl.deleteProduct(id);
	}

	@RequestMapping(method=RequestMethod.GET, value="/viewProducts")
	public List<Product> viewproducts() {
		return productServiceImpl.viewProducts();
	}
}
