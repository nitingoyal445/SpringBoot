package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootShoppingSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootShoppingSampleApplication.class, args);
	}

}
