package com.capgemini.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="product")
public class Product {
	
	@Id
	@Pattern(regexp="[a-z][0-9]+",message="Valid Price is required")
	private String id;
	
	@NotNull
	@Pattern(regexp="^[A-Z][a-z]+$",message="valid name is required")
	private String name;
	@NotNull
	@Pattern(regexp="^[A-Z][a-z]+$",message="valid model is required")
	private String model;

	
	private int price;
	/**
	 * 
	 */
	public Product() {
		super();
	}
	/**
	 * @param id
	 * @param name
	 * @param model
	 * @param price
	 */
	
	public String getId() {
		return id;
	}
	/**
	 * @param id
	 * @param name
	 * @param model
	 * @param price
	 */
	
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @param id
	 * @param name
	 * @param model
	 * @param price
	 */
	public Product(@Pattern(regexp = "[1-9][0-9]+", message = "Valid Price is required") String id,
			@NotNull @Pattern(regexp = "^[A-Z][a-z]+$", message = "valid name is required") String name,
			@NotNull @Pattern(regexp = "^[A-Z][a-z]+$", message = "valid name is required") String model, int price) {
		super();
		this.id = id;
		this.name = name;
		this.model = model;
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getPrice() {
		return price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}
	public void setPrice(int price) {
		this.price = price;
	}

}
