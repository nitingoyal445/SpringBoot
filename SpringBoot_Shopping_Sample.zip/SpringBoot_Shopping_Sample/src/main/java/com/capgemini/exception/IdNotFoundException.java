package com.capgemini.exception;

public class IdNotFoundException extends RuntimeException {
public IdNotFoundException(String string) {
super(string);	
}
}
