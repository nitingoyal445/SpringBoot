package com.capgemini.exception;

public class IdAlreadyExistException extends RuntimeException {
	public IdAlreadyExistException(String string) {
		super(string);
	}
}
